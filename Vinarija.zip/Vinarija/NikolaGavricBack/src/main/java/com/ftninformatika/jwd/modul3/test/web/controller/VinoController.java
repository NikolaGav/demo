package com.ftninformatika.jwd.modul3.test.web.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ftninformatika.jwd.modul3.test.model.Vino;
import com.ftninformatika.jwd.modul3.test.service.VinoService;
import com.ftninformatika.jwd.modul3.test.support.VinoDtoToVino;
import com.ftninformatika.jwd.modul3.test.support.VinoToVinoDto;
import com.ftninformatika.jwd.modul3.test.web.dto.VinoDto;

@RestController
@RequestMapping(value = "/api/vina", produces = MediaType.APPLICATION_JSON_VALUE)
public class VinoController {
	
	@Autowired
	private VinoService vinoService;
	
	@Autowired
	private VinoToVinoDto toVinoDto;
	
	@Autowired
	private VinoDtoToVino toVino;
	
//	@PreAuthorize("hasAnyRole('ROLE_KORISNIK', 'ROLE_ADMIN')")
	@GetMapping
	public ResponseEntity<List<VinoDto>> getAll(
			@RequestParam(required = false) String imeVina,
			@RequestParam(required = false) Long vinarijaId,
			@RequestParam(required = false, defaultValue = "0") Integer pageNo
			){
		
		System.out.println(imeVina + vinarijaId + pageNo);
		
		Page<Vino> dtoVino = vinoService.findSearch(vinarijaId, imeVina, pageNo);
		
		HttpHeaders headers = new HttpHeaders();
		headers.add("Total-Pages", Integer.toString(dtoVino.getTotalPages()));
		
		
		return new ResponseEntity<List<VinoDto>>(toVinoDto.convert(dtoVino.getContent()), headers, HttpStatus.OK);
	}
	
//	@PreAuthorize("hasAnyRole('ROLE_KORISNIK', 'ROLE_ADMIN')")
	@GetMapping("/{id}")
	public ResponseEntity<VinoDto> getOne(@PathVariable Long id){
		Vino vino = vinoService.findOne(id);
		
		if(vino != null) {
			return new ResponseEntity<VinoDto>(toVinoDto.convert(vino), HttpStatus.OK);
		} else {
			return new ResponseEntity<VinoDto>(HttpStatus.NOT_FOUND);
		}
		
	}
	
//	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<VinoDto> create(@RequestBody VinoDto vinoDto){
		
		Vino save = vinoService.save(toVino.convert(vinoDto));
		
		return new ResponseEntity<VinoDto>(toVinoDto.convert(save), HttpStatus.CREATED);
	}
	
//	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@PutMapping(value = "/{id}", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<VinoDto> update(@PathVariable Long id, @Valid @RequestBody VinoDto vinoDto){
		
		if(id != vinoDto.getId()) {
			return new ResponseEntity<VinoDto>(HttpStatus.BAD_REQUEST);
		} else {
			Vino vino = vinoService.save(toVino.convert(vinoDto));
			
			return new ResponseEntity<VinoDto>(toVinoDto.convert(vino), HttpStatus.OK);
		}
		
	}
	
//	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@DeleteMapping("/{id}")
	public ResponseEntity<Void> delete(@PathVariable Long id){
		
		if(vinoService.findOne(id) != null) {
			vinoService.delete(vinoService.findOne(id));
			return new ResponseEntity<>(HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		
	}
	

}
















