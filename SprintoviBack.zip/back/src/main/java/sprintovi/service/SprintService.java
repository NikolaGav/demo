package sprintovi.service;

import java.util.List;

import sprintovi.model.Sprint;

public interface SprintService {
	
	Sprint findOne(Long id);
	
	List<Sprint> findAll();
	
	
	

}
