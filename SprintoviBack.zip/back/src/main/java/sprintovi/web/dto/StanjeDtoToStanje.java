package sprintovi.web.dto;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import sprintovi.model.Stanje;
import sprintovi.service.StanjeService;

@Component
public class StanjeDtoToStanje implements Converter<StanjeDto, Stanje> {
	
	@Autowired
	private StanjeService stanjeService;

	@Override
	public Stanje convert(StanjeDto source) {
		
		Stanje stanje;
		
		if(source.getId() == null) {
			stanje = new Stanje();
		} else {
			stanje = stanjeService.findOne(source.getId());
		}
		
		if(stanje != null) {
			stanje.setIme(source.getIme());
		}
		
		return stanje;
	}

}
