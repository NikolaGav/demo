INSERT INTO `user` (id, username, password, role)
              VALUES (1,'miroslav','$2y$12$NH2KM2BJaBl.ik90Z1YqAOjoPgSd0ns/bF.7WedMxZ54OhWQNNnh6','ADMIN');
INSERT INTO `user` (id, username, password, role)
              VALUES (2,'tamara','$2y$12$DRhCpltZygkA7EZ2WeWIbewWBjLE0KYiUO.tHDUaJNMpsHxXEw9Ky','KORISNIK');
INSERT INTO `user` (id, username, password, role)
              VALUES (3,'petar','$2y$12$i6/mU4w0HhG8RQRXHjNCa.tG2OwGSVXb0GYUnf8MZUdeadE4voHbC','KORISNIK');
              
              

INSERT INTO sprint (id, ime, ukupno_bodova)
				VALUES (1, 'Nome 1', '10');
INSERT INTO sprint (id, ime, ukupno_bodova)
				VALUES (2, 'Nome 2', '11');
INSERT INTO sprint (id, ime, ukupno_bodova)
				VALUES (3, 'Nome 3', '12');
				
				
INSERT INTO stanje (id, ime)
				VALUES (1, 'Nome 4');
INSERT INTO stanje (id, ime)
				VALUES (2, 'Nome 5');
INSERT INTO stanje (id, ime)
				VALUES (3, 'Nome 6');
              


INSERT INTO zadatak (id, bodovi, ime, zaduzeni, sprint_id, stanje_id)
				VALUES (1, 10, 'Nome 7', 'Non so', 1, 1);
INSERT INTO zadatak (id, bodovi, ime, zaduzeni, sprint_id, stanje_id)
				VALUES (2, 11, 'Nome 8', 'Non so 1', 2, 2);
INSERT INTO zadatak (id, bodovi, ime, zaduzeni, sprint_id, stanje_id)
				VALUES (3, 12, 'Nome 9', 'Non so 2', 3, 3);