package sprintovi.web.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import sprintovi.model.Zadatak;
import sprintovi.service.ZadatakService;
import sprintovi.web.dto.ZadatakDto;
import sprintovi.web.dto.ZadatakDtoToZadatak;
import sprintovi.web.dto.ZadatakToZadatakDto;

@RestController
@RequestMapping(value = "/api/zadaci", produces = MediaType.APPLICATION_JSON_VALUE)
public class ZadatakController {

	@Autowired
	private ZadatakService zadatakService;

	@Autowired
	private ZadatakDtoToZadatak toZadatak;

	@Autowired
	private ZadatakToZadatakDto toZadatakDto;
	
	
	@GetMapping
	public ResponseEntity<List<ZadatakDto>> getAll(
			@RequestParam(required = false) String imeZadatka,
			@RequestParam(required = false) Long idSprint,
			@RequestParam(value = "pageNo", defaultValue = "0") Integer pageNo
			){
		
		 Page<Zadatak> page = zadatakService.find(imeZadatka, idSprint, pageNo);
		 
		 HttpHeaders headers = new HttpHeaders();
		 headers.add("Total-Pages", Integer.toString(page.getTotalPages()));
		
		return new ResponseEntity<>(toZadatakDto.convert(page.getContent()), headers, HttpStatus.OK);
	}
	
	
	
	@DeleteMapping(value = "/{id}")
	public ResponseEntity<Void> delete(@PathVariable Long id){
		
		if(zadatakService.findOne(id) != null) {
			zadatakService.delete(zadatakService.findOne(id));
			return new ResponseEntity<>(HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			
		}

	}
	

	@PutMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ZadatakDto> update(@PathVariable Long id, @RequestBody ZadatakDto dto){
		
		if(id != dto.getId()) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		} else {
			Zadatak zadatak = zadatakService.save(toZadatak.convert(dto));
			
			return new ResponseEntity<ZadatakDto>(toZadatakDto.convert(zadatak), HttpStatus.ACCEPTED);
		}
		
	}
	
	

	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ZadatakDto> create(@Valid @RequestBody ZadatakDto dto){

		Zadatak zadatak = zadatakService.save(toZadatak.convert(dto));
		
		return  new ResponseEntity<ZadatakDto>(toZadatakDto.convert(zadatak), HttpStatus.CREATED);
	}
	
	
	@GetMapping("/{id}")
	public ResponseEntity<ZadatakDto> getOne(@PathVariable Long id){

		Zadatak zadatak = zadatakService.findOne(id);

		if(zadatak != null) {
			return new ResponseEntity<>(toZadatakDto.convert(zadatak), HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			
		}
	}
	
	


}
