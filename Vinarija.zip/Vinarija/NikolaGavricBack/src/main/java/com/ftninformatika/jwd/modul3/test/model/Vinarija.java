package com.ftninformatika.jwd.modul3.test.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Vinarija {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(nullable = false)
	private String ime;
	
	@Column
	private Integer godinaOsnivanja;
	
	@OneToMany(mappedBy = "vinarija")
	private List<Vino> vino;

	public Vinarija() {
		super();
	}

	public Vinarija(Long id, String ime, Integer godinaOsnivanja, List<Vino> vino) {
		super();
		this.id = id;
		this.ime = ime;
		this.godinaOsnivanja = godinaOsnivanja;
		this.vino = vino;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getIme() {
		return ime;
	}

	public void setIme(String ime) {
		this.ime = ime;
	}

	public Integer getGodinaOsnivanja() {
		return godinaOsnivanja;
	}

	public void setGodinaOsnivanja(Integer godinaOsnivanja) {
		this.godinaOsnivanja = godinaOsnivanja;
	}

	public List<Vino> getVino() {
		return vino;
	}

	public void setVino(List<Vino> vino) {
		this.vino = vino;
	}
	
	
	
	
	

}
