package com.ftninformatika.jwd.modul3.test.support;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.ftninformatika.jwd.modul3.test.model.Vino;
import com.ftninformatika.jwd.modul3.test.service.TipVinaService;
import com.ftninformatika.jwd.modul3.test.service.VinarijaService;
import com.ftninformatika.jwd.modul3.test.service.VinoService;
import com.ftninformatika.jwd.modul3.test.web.dto.VinoDto;

@Component
public class VinoDtoToVino  implements Converter<VinoDto, Vino>{
	
	@Autowired
	private VinoService vinoService;
	
	@Autowired
	private TipVinaService tipVinaService;

	@Autowired
	private VinarijaService vinarijaService;
	
	@Override
	public Vino convert(VinoDto source) {
		
		Vino vino;
		
		if(source.getId() == null) {
			vino = new Vino();
		} else {
			vino = vinoService.findOne(source.getId());
		}
		
		vino.setIme(source.getIme());
		vino.setOpis(source.getOpis());
		vino.setGodinaProizvodnje(source.getGodinaProizvodnje());
		vino.setCenaFlase(source.getCenaFlase());
		vino.setBrojDosupnihFlasa(source.getBrojDosupnihFlasa());
		vino.setTipVina(tipVinaService.findOne(source.getTipVinaId()));
		vino.setVinarija(vinarijaService.findOne(source.getVinarijaId()));
		
		return vino;
	}

}
