package sprintovi.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import sprintovi.model.Zadatak;
import sprintovi.repository.ZadatakRepository;
import sprintovi.service.ZadatakService;

@Service
public class JpaZadatakService implements ZadatakService {
	
	@Autowired
	private ZadatakRepository zadatakRepository;

	@Override
	public Zadatak findOne(Long id) {
		return zadatakRepository.findOneById(id);
	}

	@Override
	public Zadatak save(Zadatak zadatak) {
		return zadatakRepository.save(zadatak);
	}

	@Override
	public void delete(Zadatak zadatak) {
		zadatakRepository.delete(zadatak);
		
	}

}
