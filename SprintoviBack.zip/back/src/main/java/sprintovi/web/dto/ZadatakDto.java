package sprintovi.web.dto;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;

public class ZadatakDto {
	
	
	private Long id;
	
	@NotBlank
	@NotNull(message = "Ime mora biti popunjen")
	@Length(max = 40)
	private String ime;
	
	private String zaduzeni;
	
	@Min(value = 0)
	@Max(value = 20)
	private Integer bodovi;
	
	private Long sprintId;
	
	private String sprintNaziv;
	
	private Long stanjeId;
	
	private String stanjeNaziv;

	public ZadatakDto() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getIme() {
		return ime;
	}

	public void setIme(String ime) {
		this.ime = ime;
	}

	public String getZaduzeni() {
		return zaduzeni;
	}

	public void setZaduzeni(String zaduzeni) {
		this.zaduzeni = zaduzeni;
	}

	public Integer getBodovi() {
		return bodovi;
	}

	public void setBodovi(Integer bodovi) {
		this.bodovi = bodovi;
	}

	public Long getSprintId() {
		return sprintId;
	}

	public void setSprintId(Long sprintId) {
		this.sprintId = sprintId;
	}

	public String getSprintNaziv() {
		return sprintNaziv;
	}

	public void setSprintNaziv(String sprintNaziv) {
		this.sprintNaziv = sprintNaziv;
	}

	public Long getStanjeId() {
		return stanjeId;
	}

	public void setStanjeId(Long stanjeId) {
		this.stanjeId = stanjeId;
	}

	public String getStanjeNaziv() {
		return stanjeNaziv;
	}

	public void setStanjeNaziv(String stanjeNaziv) {
		this.stanjeNaziv = stanjeNaziv;
	}
	
	
	

}
