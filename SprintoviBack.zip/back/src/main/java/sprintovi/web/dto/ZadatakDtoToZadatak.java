package sprintovi.web.dto;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import sprintovi.model.Zadatak;
import sprintovi.service.SprintService;
import sprintovi.service.StanjeService;
import sprintovi.service.ZadatakService;

@Component
public class ZadatakDtoToZadatak implements Converter<ZadatakDto, Zadatak> {
	
	@Autowired
	private ZadatakService zadatakService;

	@Autowired
	private SprintService sprintService;
	
	@Autowired
	private StanjeService stanjeService;
	
	
	@Override
	public Zadatak convert(ZadatakDto source) {
		
		Zadatak zadatak;
		
		if(source.getId() == null) {
			zadatak = new Zadatak();
		} else {
			zadatak = zadatakService.findOne(source.getId());
		}
		
		if(zadatak != null) {
			zadatak.setIme(source.getIme());
			zadatak.setZaduzeni(source.getZaduzeni());
			zadatak.setBodovi(source.getBodovi());
			zadatak.setSprint(sprintService.findOne(source.getId()));
			zadatak.setStanje(stanjeService.findOne(source.getId()));
		}
		
		
		return zadatak;
	}

}
