package com.ftninformatika.jwd.modul3.test.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ftninformatika.jwd.modul3.test.model.Vino;

@Repository
public interface VinoRepository extends JpaRepository<Vino, Long> {

	Page<Vino> findByImeIgnoreCaseContains(String imeVina, Pageable pageNo);

	Page<Vino> findByImeIgnoreCaseContainsAndVinarijaId(String imeVina, Long vinarijaId, Pageable pageNo);

}
