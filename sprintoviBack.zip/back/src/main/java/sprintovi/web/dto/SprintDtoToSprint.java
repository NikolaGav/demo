package sprintovi.web.dto;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import sprintovi.model.Sprint;
import sprintovi.service.SprintService;

@Component
public class SprintDtoToSprint implements Converter<SprintDto, Sprint> {
	
	@Autowired
	private SprintService sprintService;

	@Override
	public Sprint convert(SprintDto source) {
		Sprint sprint;
		
		if(source.getId() == null) {
			sprint = new Sprint();
		} else {
			sprint = sprintService.findOne(source.getId());
		}
		
		if(sprint != null) {
			sprint.setIme(source.getIme());
			sprint.setUkupnoBodova(source.getUkupnoBodova());
		}
		
		return sprint;
	}

}
