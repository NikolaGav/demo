package sprintovi.web.dto;

import java.util.ArrayList;
import java.util.List;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import sprintovi.model.Zadatak;

@Component
public class ZadatakToZadatakDto implements Converter<Zadatak, ZadatakDto> {

	@Override
	public ZadatakDto convert(Zadatak source) {
		
		ZadatakDto dto = new ZadatakDto();
		
		dto.setId(source.getId());
		dto.setIme(source.getIme());
		dto.setZaduzeni(source.getZaduzeni());
		dto.setBodovi(source.getBodovi());
		dto.setSprintId(source.getSprint().getId());
		dto.setSprintNaziv(source.getSprint().getIme());
		dto.setStanjeId(source.getStanje().getId());
		dto.setStanjeNaziv(source.getStanje().getIme());
		
		return dto;
	}
	
	
	
	public List<ZadatakDto> convert(List<Zadatak> zadatak){
		
		List<ZadatakDto> dto = new ArrayList<>();
		
		for(Zadatak itZadatak : zadatak) {
			dto.add(convert(itZadatak));
		}
		
		return dto;
	}

}
