package sprintovi.service;

import org.springframework.data.domain.Page;

import sprintovi.model.Zadatak;

public interface ZadatakService {
	
	
	Zadatak findOne(Long id);
	
	Zadatak save (Zadatak zadatak);
	
	void delete(Zadatak zadatak);
	
	Page<Zadatak> find(String imeZadatka, Long sprintId, Integer pageNo);
	

}
