package sprintovi.service;

import sprintovi.model.Zadatak;

public interface ZadatakService {
	
	
	Zadatak findOne(Long id);
	
	Zadatak save (Zadatak zadatak);
	
	void delete(Zadatak zadatak);
	

}
