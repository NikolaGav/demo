package com.ftninformatika.jwd.modul3.test.support;

import java.util.ArrayList;
import java.util.List;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.ftninformatika.jwd.modul3.test.model.Vino;
import com.ftninformatika.jwd.modul3.test.web.dto.VinoDto;

@Component
public class VinoToVinoDto implements Converter<Vino, VinoDto> {

	@Override
	public VinoDto convert(Vino source) {
		
		VinoDto dto = new VinoDto();
		
		dto.setId(source.getId());
		dto.setIme(source.getIme());
		dto.setOpis(source.getOpis());
		dto.setGodinaProizvodnje(source.getGodinaProizvodnje());
		dto.setCenaFlase(source.getCenaFlase());
		dto.setBrojDosupnihFlasa(source.getBrojDosupnihFlasa());
		dto.setTipVinaId(source.getTipVina().getId());
		dto.setTipVinaIme(source.getTipVina().getIme());
		dto.setVinarijaId(source.getVinarija().getId());
		dto.setVinarijaIme(source.getVinarija().getIme());
			
		return dto;
	}
	
	
	public List<VinoDto> convert(List<Vino> vino){
		
		List<VinoDto> lista = new ArrayList<>();
		
		for(Vino itVino : vino) {
			lista.add(convert(itVino));
		}
		
		return lista;
	}
	

}
