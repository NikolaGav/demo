package sprintovi.web.dto;

import java.util.ArrayList;
import java.util.List;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import sprintovi.model.Sprint;

@Component
public class SprintToSprintDto implements Converter<Sprint, SprintDto> {
	


	@Override
	public SprintDto convert(Sprint source) {
		SprintDto dto = new SprintDto();
		
		dto.setId(source.getId());
		dto.setIme(source.getIme());
		dto.setUkupnoBodova(source.getUkupnoBodova());
		
		return dto;
	}
	
	
	
	public List<SprintDto> convert(List<Sprint> sprintovi) {
		
		List<SprintDto> dto = new ArrayList<>();
		
		for(Sprint itSprint : sprintovi) {
			dto.add(convert(itSprint));
		}
		
		return dto;
	}

}
