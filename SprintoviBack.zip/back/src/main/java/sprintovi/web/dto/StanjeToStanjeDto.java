package sprintovi.web.dto;

import java.util.ArrayList;
import java.util.List;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import sprintovi.model.Stanje;

@Component
public class StanjeToStanjeDto implements Converter<Stanje, StanjeDto> {

	@Override
	public StanjeDto convert(Stanje source) {
		
		StanjeDto dto = new StanjeDto();
		
		dto.setId(source.getId());
		dto.setIme(source.getIme());
		
		return dto;
	}
	
	
	public List<StanjeDto> convert(List<Stanje> stanje){
		
		List<StanjeDto> dto = new ArrayList<>();
		
		for(Stanje itStanje : stanje) {
			dto.add(convert(itStanje));
		}
		
		return dto;
	}

}
