package sprintovi.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import sprintovi.model.Sprint;
import sprintovi.repository.SprintRepository;
import sprintovi.service.SprintService;

@Service
public class JpaSprintService implements SprintService {
	
	@Autowired
	private SprintRepository sprintRepository;

	@Override
	public Sprint findOne(Long id) {
		return sprintRepository.findOneById(id);
	}

	@Override
	public List<Sprint> findAll() {
		return sprintRepository.findAll();
	}

}
