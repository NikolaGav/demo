package sprintovi.service;

import java.util.List;

import sprintovi.model.Stanje;

public interface StanjeService {
	
	
	Stanje findOne(Long id);
	
	List<Stanje> findALl();

}
