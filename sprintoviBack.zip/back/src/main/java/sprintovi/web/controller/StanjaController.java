package sprintovi.web.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import sprintovi.model.Stanje;
import sprintovi.service.StanjeService;
import sprintovi.web.dto.StanjeDto;
import sprintovi.web.dto.StanjeToStanjeDto;

@RestController
@RequestMapping(value = "/api/stanja", produces = MediaType.APPLICATION_JSON_VALUE)
public class StanjaController {
	
	@Autowired
	private StanjeService stanjeService;
	
	@Autowired
	private StanjeToStanjeDto toStanjeDto;
	
	
	@GetMapping
	public ResponseEntity<List<StanjeDto>> getAll(){
		
		List<Stanje> stanja = stanjeService.findAll();
		
		return new ResponseEntity<List<StanjeDto>>(toStanjeDto.convert(stanja), HttpStatus.OK);
	}
	

}
