package sprintovi.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import sprintovi.model.Stanje;
import sprintovi.repository.StanjeRepository;
import sprintovi.service.StanjeService;

@Service
public class JpaStanjeService implements StanjeService {
	
	@Autowired
	private StanjeRepository stanjeRepository;

	@Override
	public Stanje findOne(Long id) {
		return stanjeRepository.findOneById(id);
	}

	@Override
	public List<Stanje> findALl() {
		return stanjeRepository.findAll();
	}

}
