package sprintovi.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import sprintovi.model.Zadatak;
import sprintovi.repository.ZadatakRepository;
import sprintovi.service.ZadatakService;

@Service
public class JpaZadatakService implements ZadatakService {
	
	@Autowired
	private ZadatakRepository zadatakRepository;

	@Override
	public Zadatak findOne(Long id) {
		return zadatakRepository.findOneById(id);
	}

	@Override
	public Zadatak save(Zadatak zadatak) {
		return zadatakRepository.save(zadatak);
	}

	@Override
	public void delete(Zadatak zadatak) {
		zadatakRepository.delete(zadatak);
		
	}

	@Override
	public Page<Zadatak> find(String imeZadatka, Long sprintId, Integer pageNo) {
		
		if(imeZadatka == null) {
			return zadatakRepository.findByImeIgnoreCaseContains(imeZadatka, PageRequest.of(pageNo, 3));
		}
		
		return zadatakRepository.findByImeIgnoreCaseContainsAndSprintId(imeZadatka, sprintId, PageRequest.of(pageNo, 3));
	}

}
