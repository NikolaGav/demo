package com.ftninformatika.jwd.modul3.test.model;

public class EsempiPerTest {
		
	/*
	
	
	ESEMPI PER IL DATA.SQL
	
	INSERT INTO drzava (id, naziv, oznaka)
              VALUES (1,'Italia','IT');
	INSERT INTO drzava (id, naziv, oznaka)
              VALUES (2,'Svezia','sw');
	INSERT INTO drzava (id, naziv, oznaka)
              VALUES (3,'Germania','Ge');
	
	INSERT INTO takmicar (id, broj_medalja, datum_rodjenja, imeiprezime, drzava_id)
              VALUES (1, 10,'1999-06-21','Nikola', 1);
	INSERT INTO takmicar (id, broj_medalja, datum_rodjenja, imeiprezime, drzava_id)
              VALUES (2,  5,'1995-07-22','Marko', 2);
	INSERT INTO takmicar (id, broj_medalja, datum_rodjenja, imeiprezime, drzava_id)
              VALUES (3, 20,'1993-08-12','Luka', 3);
	
	
	ESEMPI MANYTOONE
	
	@Entity
public class Linija {

	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY)
	Long Id;
	
	@Column( nullable = false, unique = true)
	String name;
	
	@ManyToOne
	State prevoznik;

	public Linija() {
		super();
	}
	
	
	ESEMPI ONETOMANY
	
	@Entity
public class Prevoznik{

@Id
@GeneratedValue( strategy = GenerationType.IDENTITY)
private Long Id;

@Column( nullable = false, unique = true)
private String name;

@OneToMany(mappedBy = "prevoznik", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
private List<Linija> linije = new ArrayList<Task>();

public Prevoznik() {
	super();
}

	
	
	
	ESEMPI PER IL DTO 
	
	@Autowired
	private LinijaService linijaService;

	@Autowired
	private PrevoznikService prevoznikService;

	@Override
	public Linija convert(LinijaDTO source) {
		Linija linija;

		if (source.getId() == null) {
			linija = new Linija();
		}

		else {
			linija = linijaService.findOne(source.getId());
		}

		linija.setBrojMesta(source.getBrojMesta());
		linija.setCenaKarte(source.getCenaKarte());
		linija.setPrevoznik(prevoznikService.findOneById(source.getPrevoznikId()));
		linija.setVremePolaska(source.getVremePolaska());
		linija.setDestinacija(source.getDestinacija());

		return linija;
	}
	
	
	@Override
	public LinijaDTO convert(Linija linija) {
		LinijaDTO lDto = new LinijaDTO();
		lDto.setId(linija.getId());
		lDto.setBrojMesta(linija.getBrojMesta());
		lDto.setDestinacija(linija.getDestinacija());
		lDto.setCenaKarte(linija.getCenaKarte());
		lDto.setVremePolaska(linija.getVremePolaska());
		lDto.setPrevoznikId(linija.getPrevoznik().getId());
		lDto.setPrevoznikNaziv(linija.getPrevoznik().getNaziv());

		return lDto;

	}

	public List<LinijaDTO> convert(List<Linija> linije) {
		List<LinijaDTO> listDto = new ArrayList<>();

		for (Linija l : linije) {
			listDto.add(convert(l));
		}
		return listDto;
	}
	
	
	ANNOTAZIONI
	
	
	@Entity

@Column
@Column (unique = true)

@NotNull
@NotBlank
@NotEmpty

@Min (value = 10)
@Max (value = 50)
@Length (min = 10, max = 50)
@Size (min = 10, max = 50)


	
	

	ESEMPI PER IL CONTROLLER 
	
	@PreAuthorize("hasRole('ADMIN')")
	@PreAuthorize("hasAnyRole('KORISNIK', 'ADMIN')")
	
	@GetMapping
	public ResponseEntity<List<LinijaDTO>> getAll(
			@RequestParam(required = false) String destinacija,
			@RequestParam(required = false) Long idPrevoznika,
			@RequestParam(required = false) Double maksimalnaCena,
			@RequestParam(required = false, defaultValue = "0") Integer pageNo) {
		
		System.out.println(destinacija + " " + idPrevoznika + " " + maksimalnaCena + " " + pageNo);
		Page<Linija> dtoLinije = linijaService.findSearch(destinacija, idPrevoznika, maksimalnaCena, pageNo);

		HttpHeaders headers = new HttpHeaders();
		headers.add("total-Pages", Integer.toString(dtoLinije.getTotalPages()));

		return new ResponseEntity<List<LinijaDTO>>(toLinijaDto.convert(dtoLinije.getContent()), headers, HttpStatus.OK);
	}

	@GetMapping("/{id}")
	public ResponseEntity<LinijaDTO> getOne(@PathVariable Long id) {
		System.out.println(id);
		Linija linija = linijaService.findOne(id);
		if (linija == null) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}

		else {
			return new ResponseEntity<>(toLinijaDto.convert(linija), HttpStatus.OK);
		}
	}

	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<LinijaDTO> create(@RequestBody LinijaDTO linijaDTO) {
		Linija sacuvanaLinija = linijaService.save(toLinija.convert(linijaDTO));

		return new ResponseEntity<LinijaDTO>(toLinijaDto.convert(sacuvanaLinija), HttpStatus.CREATED);
	}

	@PutMapping(value = "/{id}", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<LinijaDTO> update(@PathVariable Long id, @RequestBody LinijaDTO linijaDTO) {

		if (id != linijaDTO.getId()) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}

		else {
			Linija linija = linijaService.save(toLinija.convert(linijaDTO));

			return new ResponseEntity<LinijaDTO>(toLinijaDto.convert(linija), HttpStatus.ACCEPTED);
		}
	}

	@DeleteMapping(value = "/{id}")
	public ResponseEntity<Void> delete(@PathVariable Long id) {

		if (linijaService.findOne(id) != null) {
			linijaService.delete(linijaService.findOne(id));
			return new ResponseEntity<>(HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}

	}
	
	
	ESEMPI PER IL SERVICE
	
	Linija findOne(Long id);
	Linija save (Linija linija);
	 void delete(Linija linija);
	 Page<Linija> findSearch(String destinacija, Long idPrevoznika, Double maksimalnaCena, Integer pageNo);
	List<Prevoznik> getAll();
	
	EMEPI JPA
	
	@Override
	public Linija findOne(Long id) {
		Optional<Linija> linija = linijaRepository.findById(id);
		if (linija.isPresent()) {
			return linija.get();
		}
		return null;
	}
	
	@Override
	public void delete(Linija linija) {
		 linijaRepository.delete(linija);
	}
	
	Page<Linija> findByDestinacijaIgnoreCaseContainsAndCenaKarteLessThanEqualAndPrevoznikId(String destinacija, Double maksimalnaCena, Long idPrevoznika, Pageable pageNo);
	
	
	
	
	REPOSITORY
	
	
	@Repository
public interface EntityRepository extends JpaRepository<Entity, Long>{	
	Entity findOneById(Long id);
	Page<Entity> findByCenaKarteLessThanEqualAndDestinacijaIgnoreCaseContains( Double cenaKarte, 
							String destinacija, Pageable pageNo);
	Page<Entity> findByDestinacijaIgnoreCaseContainsAndCenaKarteLessThanEqualAndPrevoznikId(String destinacija, 
							Double maksimalnaCena, Long idPrevoznika, Pageable pageNo);
}


	Repository Metode
	
	
	// zadatak sa linijama
Page<Linija> findByCenaKarteLessThanEqualAndDestinacijaIgnoreCaseContains
					( Double cenaKarte, String destinacija, Pageable pageNo);
Page<Linija> findByDestinacijaIgnoreCaseContainsAndCenaKarteLessThanEqualAndPrevoznikId
					(String destinacija, Double maksimalnaCena, Long idPrevoznika, Pageable pageNo);

// korisnici
Optional<Korisnik> findFirstByKorisnickoIme
					(String korisnickoIme);
Optional<Korisnik> findFirstByKorisnickoImeAndLozinka
					(String korisnickoIme,String lozinka);

// zadatak sa 13-end (task and sprints)
@Query("SELECT t FROM Task t WHERE" +
			"(:taskName = NULL OR t.name LIKE :taskName) AND " + 
			"(:sprintId = NULL OR t.sprint.id = :sprintId)")
	Page<Task> search(@Param("taskName") String taskName, @Param("sprintId") Long sprintId, Pageable pageable);

@Query("SELECT COALESCE(SUM(t.points),0) FROM Task t WHERE t.sprint.id = :sprintId")
	Long sumPoints(Long sprintId);

// olimpijske igre
Country findOneById(Long id); // vraca Objekat ne <Optional>

Competitor findOneById(Long id);
Page<Competitor> findByMedalsNoBetween(Integer minMedals, Integer maxMedals, 
				Pageable p);
Page<Competitor> findByCountryIdAndMedalsNoBetween(Long countryId, Integer minMedals, 
				Integer maxMedals, Pageable of);

// proizvodi
Page<Product> findByPriceBetween(Double minPrice, Double maxPrice, Pageable of);
Page<Product> findByCategoriesIdAndPriceBetween(Long categoriesId, 
				Double minPrice, Double maxPrice, Pageable of);
				
				
				
				
	

	
	ESEMPI RANDOM CHE POSSONO ESSERE UTILI
	
	
	// zadatak sa linijama
Page<Linija> findByCenaKarteLessThanEqualAndDestinacijaIgnoreCaseContains
					( Double cenaKarte, String destinacija, Pageable pageNo);
Page<Linija> findByDestinacijaIgnoreCaseContainsAndCenaKarteLessThanEqualAndPrevoznikId
					(String destinacija, Double maksimalnaCena, Long idPrevoznika, Pageable pageNo);

// korisnici
Optional<Korisnik> findFirstByKorisnickoIme
					(String korisnickoIme);
Optional<Korisnik> findFirstByKorisnickoImeAndLozinka
					(String korisnickoIme,String lozinka);

// zadatak sa 13-end (task and sprints)
@Query("SELECT t FROM Task t WHERE" +
			"(:taskName = NULL OR t.name LIKE :taskName) AND " + 
			"(:sprintId = NULL OR t.sprint.id = :sprintId)")
	Page<Task> search(@Param("taskName") String taskName, @Param("sprintId") Long sprintId, Pageable pageable);

@Query("SELECT COALESCE(SUM(t.points),0) FROM Task t WHERE t.sprint.id = :sprintId")
	Long sumPoints(Long sprintId);

// olimpijske igre
Country findOneById(Long id); // vraca Objekat ne <Optional>

Competitor findOneById(Long id);
Page<Competitor> findByMedalsNoBetween(Integer minMedals, Integer maxMedals, 
				Pageable p);
Page<Competitor> findByCountryIdAndMedalsNoBetween(Long countryId, Integer minMedals, 
				Integer maxMedals, Pageable of);

// proizvodi
Page<Product> findByPriceBetween(Double minPrice, Double maxPrice, Pageable of);
Page<Product> findByCategoriesIdAndPriceBetween(Long categoriesId, 
				Double minPrice, Double maxPrice, Pageable of);
	
	
	
	
	ESEMPI PER IL FRONT
	SEARCH FORM
	
	<div className="search">
              <Form style={{ width: "100%" }}>
                <Row>
                  <Col>
                    <Form.Group>
                      <Form.Label>Drzava Takmicara</Form.Label>
                      <Form.Select
                        name="countryId"
                        as="input"
                        type="text"
                        onChange={(e) => this.onSearchInputChange(e)}
                      >
                        <option value=""></option>
                        {this.renderCountriesInDropDown()}
                      </Form.Select>
                    </Form.Group>
                  </Col>
                </Row>

                <Row>
                  <Col>
                    <Form.Group>
                      <Form.Label>Broj medalja od</Form.Label>
                      <Form.Control
                        name="minMedals"
                        as="input"
                        type="number"
                        onChange={(e) => this.onSearchInputChange(e)}
                      ></Form.Control>
                    </Form.Group>
                  </Col>
                  <Col>
                    <Form.Group>
                      <Form.Label>Broj medalja do</Form.Label>
                      <Form.Control
                        name="maxMedals"
                        as="input"
                        type="number"
                        onChange={(e) => this.onSearchInputChange(e)}
                      ></Form.Control>
                    </Form.Group>
                  </Col>
                </Row>
              </Form>
              <Row>
                <Col>
                  <Button onClick={() => this.getCompetitors()}>
                    Pretrazi
                  </Button>
                </Col>
              </Row>
            </div>
	
	
	
	
	NEW ENTITY TABLE
	
	<div>
          <Form style={{ width: "100%" }}>
            <Row>
              <Col>
                <Form.Group>
                  <Form.Label>Ime i prezime takmicara</Form.Label>
                  <Form.Control
                    name="firstLastName"
                    as="input"
                    type="text"
                    placeholder="Unesi ime i prezime"
                    onChange={(e) => this.onInputChange(e)}
                  ></Form.Control>
                </Form.Group>
              </Col>
            </Row>

            <Row>
              <Col>
                <Form.Group>
                  <Form.Label>Datum Rodjenja</Form.Label>
                  <Form.Control
                    type="date"
                    name="date"
                    onChange={(e) => this.onInputChange(e)}
                  ></Form.Control>
                </Form.Group>
              </Col>
            </Row>
            <Row>
              <Col>
                <Form.Group>
                  <Form.Label>Broj medalja do</Form.Label>
                  <Form.Control
                    name="medals"
                    as="input"
                    type="number"
                    min="0"
                    placeholder="Osvojene medalje"
                    onChange={(e) => this.onInputChange(e)}
                  ></Form.Control>
                </Form.Group>
              </Col>
            </Row>
            <Row>
              <Col>
                <Form.Group>
                  <Form.Label>Drzava takmicara</Form.Label>
                  <Form.Select
                    name="countryId"
                    onChange={(e) => this.onInputChange(e)}
                  >
                    <option>Izaberi drzavu takmicara</option>
                    {this.renderCountriesInDropDown()}
                  </Form.Select>
                </Form.Group>
              </Col>
            </Row>
          </Form>
          <br />
          <Row>
            <Col>
              <Button onClick={(e) => this.createCompetitor(e)}>
                Dodaj takmicara
              </Button>
            </Col>
          </Row>
        </div>
	
	
	
	RENDER TABLE
	
	renderEntity() {
    return this.state.entities.map((ent) => {
      return (
        <tr key={ent.id}>
          <td>{ent.id}</td>
          <td>{ent.naziv}</td>
        </tr>
      );
    });
  }

<div className="prikazEntiteta">
          <h1>Prikaz Entiteta</h1>
          <Table>
            <thead>
              <tr>
                <th>Id</th>
                <th>Naziv</th>
              </tr>
            </thead>
            <tbody>{this.renderEntity()}</tbody>
          </Table>
        </div>
        
        
        Exclude Button Based on Role
        
        <td>
{window.localStorage["role"] == "ROLE_KORISNIK" ? (
<Button onClick={() => this.toApplication(comp.id)}>Prijava</Button>) : null}
</td>

<td>
{window.localStorage["role"] == "ROLE_ADMIN" ? (
<Button onClick={() => this.toApplication(comp.id)}>Prijava</Button>) : null}
</td>

{window.localStorage["role"] == "ROLE_ADMIN" ||
 window.localStorage["role"] == "ROLE_KORISNIK" ? (
<div> </div>) : null}


Exclude Button Based on Parameter Value


{entity.racunId == null ? (
	<td>
 <Button onClick={() => this.goToEdit(entity.id)}>Kreiraj Racun</Button>
	</td>) : (
	<td>
<Button onClick={() => this.goToDelete(entity.id)}>Obrisi</Button>
	</td>
)}


Hide Table Logic



class SuperClass extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      check: true,
    };
  }

renderStats() {
	return this.state.stats.map((s) => {
		return (
			<tr key={s.id}>
				<td>{s.id}</td>
				<td>{s.name}</td>
			</tr>
					);
		});
}

render( ) {
	return(
		<Table hidden={this.state.check}>
		<thead>
			<tr>
				<th>ID</th>
				<th>Naziv</th>
			</tr>
		</thead>
			<tbody>{this.renderStats()}</tbody>
		</Table>
	)}
	
	
	Find Object based on id

	
	doNabavi(id) {
    let proizvod = this.state.entity.find((prevoznik) => prevoznik.id == id);
    console.log(proizvod);
  }
  
  
  Render Highest To Lowest
  
  
  renderStats() {
    let contriesFromState = this.state.countries;
    let highestToLowest = contriesFromState.sort((b, a) => {
      return a.medals - b.medals;
    });
    //   return this.state.countries.map((country) => {
    return highestToLowest.map((country) => {
      return (
        <tr key={country.id}>
          <td>
            {country.name}, {country.abb}
          </td>
          <td>{country.medals}</td>
        </tr>
      );
    });
  }
  

getAllEntites


getEntity() {
    OGAxios.get("/entities")
      .then((res) => {
        console.log(res);
        this.setState({ entities: res.data });
      })
      .catch((err) => {
        console.log(err);
      });
  }
  
  
  
  getAllEntities (with Params + pagination)
  
  
  componentDidMount() {
	this.getEntities(this.state.search.pageNo);
}

getEntities(newPageNo) {
    if (newPageNo < 0) {
      newPageNo = 0;
    }
    let search = this.state.search;
    let config = {
      params: {
	      id: search.id,
        name: search.name,
        date: search.date,
        pageNo: newPageNo,
      },
    };

    Axios.get("/entities", config)
      .then((res) => {
        this.setState({ pageNo: newPageNo });
        this.setState({
          entities: res.data,
          totalPages: res.headers["total-pages"],
        });
      })
      .catch((err) => {
        console.log(err);
      });
  }
  
  
  goToAddEntity
  
  
  import { withNavigation } from "../../routeconf";

     goToAddEntity() {
        this.props.navigate("/entity/add");
          }

export default withNavigation(NazivKlase));


editEntity


goToEdit(id) {
    this.props.navigate("/entity/edit/" + id);
  }

// negde u Renderu
<td>
     <button onClick={() => this.goToEdit(entity.id)}>Izmeni</button>
</td>



componentDidMount() {
    this.getEntity(this.props.params.id);
  }

  getEntity(id) {
    CinemaAxios.get("/entity/" + id)
      .then((res) => {
        this.setState({ linija: res.data });
      })
      .catch((error) => {
        console.log(error);
      });
  }
  
  
  
	
	
	
	
	
	
	






*/
}
