package com.ftninformatika.jwd.modul3.test.support;

import java.util.ArrayList;
import java.util.List;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.ftninformatika.jwd.modul3.test.model.Vinarija;
import com.ftninformatika.jwd.modul3.test.web.dto.VinarijaDto;

@Component
public class VinarijaToVinarijaDto implements Converter<Vinarija, VinarijaDto> {

	@Override
	public VinarijaDto convert(Vinarija source) {
		VinarijaDto dto = new VinarijaDto();
		
		dto.setId(source.getId());
		dto.setIme(source.getIme());
		dto.setGodinaOsnivanja(source.getGodinaOsnivanja());
		
		return dto;
	}
	
	
	public List<VinarijaDto> convert(List<Vinarija> vinarija){
		
		List<VinarijaDto> lista = new ArrayList<>();
		
		for(Vinarija itVinarija : vinarija) {
			lista.add(convert(itVinarija));
		}
		
		return lista;
	}

}
