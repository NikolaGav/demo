package com.ftninformatika.jwd.modul3.test.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ftninformatika.jwd.modul3.test.model.TipVina;
import com.ftninformatika.jwd.modul3.test.repository.TipVinaRepository;
import com.ftninformatika.jwd.modul3.test.service.TipVinaService;

@Service
public class JpaTipVinaService  implements TipVinaService{
	
	@Autowired
	private TipVinaRepository tipVinaRepository;

	@Override
	public List<TipVina> getAll() {
		List<TipVina> tipVina = tipVinaRepository.findAll();
		return tipVina;
	}

	@Override
	public TipVina findOne(Long id) {
		
		Optional<TipVina> tipVina = tipVinaRepository.findById(id);
		
		if(tipVina.isPresent()) {
			return tipVina.get();
		}
		
		return null;
	}

}
