package com.ftninformatika.jwd.modul3.test.service;

import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.ftninformatika.jwd.modul3.test.model.Vinarija;
import com.ftninformatika.jwd.modul3.test.model.Vino;

@Service
public interface VinoService {
	
	
	Vino findOne(Long id);
	
	Vino save (Vino vino);
	
	void delete (Vino vino);
	
	Page<Vino> findSearch(Long vinarijaId, String imeVina, Integer pageNo);
	
	
	

}
